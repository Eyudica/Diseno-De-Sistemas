import java.util.List;
import java.util.ArrayList;
public class Restaurante {
    private String nombre;
    private List<Sucursal> sucursal=new ArrayList<>();

    public Restaurante(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    public List<Sucursal> getSucursal(){
        return sucursal;
    }
    public void agregarSucursal(Sucursal s){
        if (!sucursal.contains(s)){
            sucursal.add(s);
        }
    }
    @Override
    public String toString(){
        return nombre;
    }
}
