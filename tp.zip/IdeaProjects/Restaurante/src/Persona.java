import java.util.ArrayList;
import java.util.List;
public class Persona {
    private String nombre;
    private int dni;
    private List<Platos> platos_favoritos=new ArrayList<>();

    public Persona(int dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }
    public List<Platos> getPlatos(){
        return platos_favoritos;
    }
    public void agregarPlatos(Platos p){
        if (!platos_favoritos.contains(p)){
            platos_favoritos.add(p);
        }
    }
}
