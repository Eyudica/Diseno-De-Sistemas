public class Main {
    public static void main(String[] args) {

        Platos pastas=new Platos("ravioles");
        Platos tacos=new Platos("tacos");
        Persona juan=new Persona(234234,"Juan Rodriguez");
        Sucursal mendoza=new Sucursal("mendoza",123);
        Restaurante test=new Restaurante("test");
        Ciudad lujan=new Ciudad("lujan");
        juan.agregarPlatos(pastas);
        mendoza.agregarPlato(pastas);
        mendoza.agregarPlato(tacos);
        test.agregarSucursal(mendoza);
        lujan.agregarRestaurante(test);
        for (Platos p : juan.getPlatos()){
            System.out.println(p.getNombre());
        }
        for (Platos p : mendoza.getPlatos()){
            System.out.println(p.getNombre());
        }
        for (Sucursal s : test.getSucursal()){
            System.out.println(s.getPlatos());
        }


    }
}