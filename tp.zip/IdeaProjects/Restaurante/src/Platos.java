public class Platos {
    private String nombre;

    public Platos(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    @Override
    public String toString(){
        return nombre;
    }
}
