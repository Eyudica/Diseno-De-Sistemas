import java.util.ArrayList;
import java.util.List;
public class Sucursal {
    private String direccion;
    private int numero_sucursal;
    private List<Platos> platos_sucursal=new ArrayList<>();

    public Sucursal(String direccion, int numero_sucursal) {
        this.direccion = direccion;
        this.numero_sucursal = numero_sucursal;
    }
    public List<Platos> getPlatos(){
        return platos_sucursal;
    }
    public void agregarPlato(Platos p){
        if (!platos_sucursal.contains(p)){
            platos_sucursal.add(p);
        }
    }
}
