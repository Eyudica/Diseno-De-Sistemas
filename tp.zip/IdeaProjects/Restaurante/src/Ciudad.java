import java.util.ArrayList;
import java.util.List;
public class Ciudad {
    public String nombre;
    public List<Restaurante> restaurante=new ArrayList<>();

    public Ciudad(String nombre) {
        this.nombre = nombre;

    }
    public void agregarRestaurante(Restaurante r) {
        if (!restaurante.contains(r)) {
            restaurante.add(r);
        }
    }
    public List<Restaurante> getRestaurante(){
        return restaurante;
    }
    }
