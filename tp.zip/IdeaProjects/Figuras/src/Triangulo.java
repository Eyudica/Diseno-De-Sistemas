public class Triangulo extends Poligono {
    public Triangulo(String color){
        super(color,3);
    }

}
