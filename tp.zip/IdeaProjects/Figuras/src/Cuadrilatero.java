public class Cuadrilatero extends Poligono{
    public Cuadrilatero(String color){
        super(color,4);
    }
}
