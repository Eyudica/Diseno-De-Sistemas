public class Rectangulo extends Cuadrilatero {
    //public Rectangulo(String color, int lados){
    //    super(color,lados); hereda directamente, lo de abajo es porque el color no siempre va a ser el mismo
    public Rectangulo(String color){
        super(color);
    }

}
