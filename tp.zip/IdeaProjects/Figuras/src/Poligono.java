public class Poligono extends Figura {
    private int lados;

    public Poligono(String color,int lados){
        super(color);
        this.lados=lados;
    }
    public int getLados(){
        return lados;
    }
}
