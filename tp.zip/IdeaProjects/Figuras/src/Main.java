import org.w3c.dom.css.CSSImportRule;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
    Figura roja=new Figura("roja");
    System.out.println(roja.getColor());
    Elipse e = new Elipse("azul");
    System.out.println(e.getFigura().getColor());
    Circulo violeta=new Circulo("violeta");
    System.out.println(violeta.getFigura().getColor());
        Triangulo amarillo = new Triangulo("amarillo");
        System.out.println("Triángulo → Color: " + amarillo.getColor() + ", Lados: " + amarillo.getLados());

        Cuadrilatero verde = new Cuadrilatero("verde");
        System.out.println("Cuadrilátero → Color: " + verde.getColor() + ", Lados: " + verde.getLados());

        Rectangulo negro = new Rectangulo("negro");
        System.out.println("Rectángulo → Color: " + negro.getColor() + ", Lados: " + negro.getLados());
    }
}