public class Circulo extends Elipse {
    //constructor
    public Circulo(String color){
        super(color);
    }
}
