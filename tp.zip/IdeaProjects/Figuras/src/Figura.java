

public class Figura {
    protected String color;
    //setter
    public Figura(String color) {
        this.color=color;
    }
   //getter
    public String getColor(){
        return color;
    }
}
