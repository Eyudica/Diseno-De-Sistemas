public class Elipse {
    private Figura figura;

    public Elipse(String color){
        this.figura=new Figura(color);
    }
    public Figura getFigura(){
        return figura;
    }
}
