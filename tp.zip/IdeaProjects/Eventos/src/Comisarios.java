import java.util.ArrayList;
import java.util.List;
public class Comisarios
{
    public String nombre;
    public int dni;
    public String rango;
    public List<Eventos> eventos;

    public Comisarios(String nombre, int dni, String rango) {
        this.nombre = nombre;
        this.dni = dni;
        this.rango = rango;
        this.eventos=new ArrayList<>();
    }
    public List<Eventos> getEventos(){
        return eventos;
    }
    public void agregarEvento(Eventos e){
        if (!eventos.contains(e)){
            eventos.add(e);
            e.getComisarios().add(this);

        }
    }

    public String getNombre() {
        return nombre;
    }


}
