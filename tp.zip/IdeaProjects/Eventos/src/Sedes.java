import java.util.ArrayList;
import java.util.List;
public class Sedes {
    public String ubicacion;
    public int numero_complejos;
    public int presupuesto;
    public List<Complejos> complejos = new ArrayList<>();

    public Sedes(String ubicacion, int presupuesto, int numero_complejos) {
        this.ubicacion = ubicacion;
        this.presupuesto = presupuesto;
        this.numero_complejos = numero_complejos;
    }
    public List<Complejos> getComplejos(){
        return complejos;
    }
    public void agregarComplejos(Complejos c){
        if (!complejos.contains(c)){
            complejos.add(c);

        }
    }
}
