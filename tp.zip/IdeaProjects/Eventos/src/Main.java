import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Comisarios jefe=new Comisarios("Rodriguez",34234,"jefe");
        Sedes lujan=new Sedes("lujan",4342,12);
        List<String> deportes1 = Arrays.asList("Futbol", "Basquet", "Tenis");
        List<String> material=Arrays.asList("porterías", "pértigas", "barras paralelas");
        Eventos evento1=new Eventos("20 de diciembre",213,"participante",material);
        Eventos evento2=new Eventos("19 de diciembre",213,"participante",material);

        Complejos complejo1=new Complejos("futbol","a2","Rodriguez",deportes1);
        jefe.agregarEvento(evento1);
        jefe.agregarEvento(evento2);

        System.out.println("Eventos a los que pertenece el comisario "+ jefe.getNombre());
        for (Eventos e : jefe.getEventos()){
            System.out.println(e.getFecha());
        }
        System.out.println(complejo1.getDeportes());

    }
}