import java.util.ArrayList;
import java.util.List;
public class Complejos {
    public String area;
    public String localizacion;
    public String jefe;
    public boolean polideportivo;
    public List<String> deportes;
    public List<Eventos> eventos=new ArrayList<>();

    public Complejos(String area, String localizacion, String jefe, List<String> deportes) {
        this.area = area;
        this.localizacion = localizacion;
        this.jefe = jefe;
        this.deportes = deportes;
        this.polideportivo=deportes.size() >1;
    }
    public List<String> getDeportes(){
        return deportes;
    }
    public void setEventos(Eventos e){
        if (!eventos.contains(e)){
            eventos.add(e);
        }
    }


}
