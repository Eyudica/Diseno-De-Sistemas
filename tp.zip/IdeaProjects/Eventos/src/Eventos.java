import java.util.ArrayList;
import java.util.List;
public class Eventos {
    private String fecha;
    private int duracion;
    private String participante;
    private  List<String> material;
    private List<Comisarios> comisarios=new ArrayList<>();

    public Eventos(String fecha, int duracion, String participante, List<String> material) {
        this.fecha = fecha;
        this.duracion = duracion;
        this.participante = participante;
        this.material = material;
    }
    public List<Comisarios> getComisarios(){
        return comisarios;
    }
    public void agregarComisario(Comisarios c){
        if (!comisarios.contains(c)){
            comisarios.add(c);
            c.getEventos().add(this);
        }
    }

    public String getFecha() {
        return fecha;
    }
}
