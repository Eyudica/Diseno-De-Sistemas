import java.util.List;
public class Cereal {
    private String nombre;
    private String estacion;
    private String tipo;
    private List<Mineral> mineral;

    public Cereal(String nombre, String estacion, String tipo, List<Mineral> mineral) {
        this.nombre = nombre;
        this.estacion = estacion;
        this.tipo = tipo;
        this.mineral=mineral;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEstacion() {
        return estacion;
    }

    public String getTipo() {
        return tipo;
    }
    public List<Mineral> getMineral(){
        return mineral;
    }
}
