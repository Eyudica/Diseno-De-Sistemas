import java.util.List;
public class Lote {
    private String direccion;
    private String tipo;
    private List<Cereal> cereales;

    public Lote(String direccion, String tipo, List<Cereal> cereales) {
        this.direccion = direccion;
        this.tipo = tipo;
        this.cereales=cereales;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTipo() {
        return tipo;
    }
    public List<Cereal> getCereales(){
        return cereales;
    }
}
