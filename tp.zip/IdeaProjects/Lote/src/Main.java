import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        Mineral magnesio = new Mineral("magnesio","Citrato de magnesio.");
        Cereal trigo = new Cereal("Trigo", "Invierno", "Grano",new ArrayList<>());
        trigo.getMineral().add(magnesio);
        Lote lote1= new Lote("lujan","agricola",new ArrayList<>());
        lote1.getCereales().add(trigo);
        for (Cereal c : lote1.getCereales()){
            System.out.println(c.getNombre());
        }

        System.out.println(lote1.getDireccion());
        System.out.println(lote1.getTipo());
        }
}