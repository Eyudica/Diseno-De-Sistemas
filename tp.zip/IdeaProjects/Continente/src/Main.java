import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Capital buenosaires=new Capital("Buenos Aires",1231221);
        Capital santiago=new Capital("Santiago",432345);
        Capital montevideo=new Capital("Montevideo",546456);
        Pais argentina = new Pais("Argentina",buenosaires);
        Pais chile = new Pais("Chile",santiago);
        Pais uruguay = new Pais("Uruguay",montevideo);
        Continente america=new Continente("America");
        Provincia mendoza = new Provincia("Mendoza");
        Provincia lapampa = new Provincia("La Pampa");
        america.agregarPais(argentina);
        america.agregarPais(uruguay);
        america.agregarPais(chile);
        // Provincias dentro de Argentina
        argentina.agregarProvincia(mendoza);
        argentina.agregarProvincia(lapampa);

        // Países vecinos
        argentina.agregarLimitrofe(chile);
        argentina.agregarLimitrofe(uruguay);

        // Provincias vecinas entre sí
        mendoza.agregarLimitrofe(lapampa);

        // Mostrar datos
        System.out.println("Provincias de " + argentina.getNombre() + ":");
        argentina.getProvincias().forEach(p -> System.out.println(" - " + p.getNombre()));
        System.out.println(argentina.getCapital());

        System.out.println("Paises del contiente "+ america.getNombre());

        for (Pais p : america.getPaises()) {
            System.out.println(p.getNombre());
        }
        }

}
