import java.util.ArrayList;
import java.util.List;
public class Continente {
    private String nombre;
    private List<Pais> paises=new ArrayList<>();

    public Continente(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Pais> getPaises(){
        return paises;
    }
    public void agregarPais(Pais p){
        if (!paises.contains(p)){
            paises.add(p);
        }
    }
}
