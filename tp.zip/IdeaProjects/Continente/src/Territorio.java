import java.util.ArrayList;
import java.util.List;

public abstract class Territorio {
    private String nombre;
    private List<Territorio> limitrofes;

    public Territorio(String nombre) {
        this.nombre = nombre;
        this.limitrofes=new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<Territorio> getLimitrofes() {
        return limitrofes;
    }

    public void agregarLimitrofe(Territorio t) {
        if (!limitrofes.contains(t)) {
            limitrofes.add(t);
            t.getLimitrofes().add(this); // relación bidireccional
        }
    }
}
