import java.util.ArrayList;
import java.util.List;

public class Pais extends Territorio {
    private List<Provincia> provincias = new ArrayList<>();
    private Capital capital;
    public Pais(String nombre,Capital capital) {
        super(nombre);
        this.capital=capital;
    }

    public void agregarProvincia(Provincia provincia) {
        if (!provincias.contains(provincia)) {
            provincias.add(provincia);
        }
    }

    public List<Provincia> getProvincias() {
        return provincias;
    }
    public Capital getCapital(){
        return capital;
    }
}
