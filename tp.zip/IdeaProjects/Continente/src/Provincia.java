import java.util.List;
public class Provincia extends Territorio {
    public Provincia(String nombre) {
        super(nombre);
    }
}
