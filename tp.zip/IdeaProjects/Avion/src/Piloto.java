public class Piloto extends Persona {
    public int licencia;
    public String restricciones;
    public String avion_permitido;
    public Avion avion;
    public Piloto(int numero_seguridad,String nombre,String direccion,int telefono,int numero,
                   int licencia,String restricciones,String avion_permitido){
        super(numero_seguridad,nombre,direccion,telefono);
        this.licencia=licencia;
        this.restricciones=restricciones;
        this.avion_permitido=avion_permitido;

    }

    public int getLicencia() {
        return licencia;
    }

    public String getRestricciones() {
        return restricciones;
    }

    public String getAvion_permitido() {
        return avion_permitido;
    }
    public void volarAvion(){
        if (avion!=null && avion.getTipo().equals(this.avion_permitido)){
            System.out.println("Volando avion "+avion.getMatricula());

        }else if (avion != null){
            System.out.println("No se permite volar este avion");
        }else{
            System.out.println("No existe el avion");
        }

}   }
