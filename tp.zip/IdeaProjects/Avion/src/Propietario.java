public class Propietario extends Persona {
    public int matricula;
    public Propietario(int numero_seguridad,String nombre,String direccion,int telefono,int numero,int matricula){
        super(numero_seguridad,nombre,direccion,telefono);
        this.matricula=matricula;
    }
    public void comprarAvion(Avion a){
        a.setPropietario(this);
        System.out.println(this.nombre+" ahora es propietario de avion "+a.getMatricula());
    }
}
