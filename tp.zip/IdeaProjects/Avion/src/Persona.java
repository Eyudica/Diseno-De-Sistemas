
public abstract class Persona {
    public int numero_seguridad;
    public String nombre;
    public String  direccion;
    public int telefono;

    public Persona(int numero_seguridad, String nombre, String direccion, int telefono) {
        this.numero_seguridad = numero_seguridad;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public int getNumero_seguridad() {
        return numero_seguridad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public int getTelefono() {
        return telefono;
    }
}
