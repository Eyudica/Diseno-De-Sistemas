import java.util.List;
import java.util.ArrayList;
public class Mecanico extends Persona{
    public int salario;
    public int turno;
    public String tipo_permitido;
    public List<Registros> registros;
    public Avion avion;
    public Mecanico(int numero_seguridad,String nombre,String direccion,int telefono,int salario,int turno,String tipo_permitido){
        super(numero_seguridad,nombre,direccion,telefono);
        this.salario=salario;
        this.turno=turno;
        this.tipo_permitido = tipo_permitido;
        this.registros=new ArrayList<>();
    }
    public void generarRegistro(String nombre_registro,String fecha,int numero,String tipo){
        Registros r=new Registros(fecha,numero,tipo);
        registros.add(r);
        System.out.println("Se ha generado un registro "+nombre_registro);
    }
    public void arreglarAvion(Avion a) {
        if (a != null && this.tipo_permitido.equals(a.tipo)) {
            System.out.println("Arreglando avión " + a.matricula);
        } else {
            System.out.println("No se permite arreglar el avión");
        }
    }

}
