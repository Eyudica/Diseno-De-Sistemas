import java.util.ArrayList;
import java.util.List;
public class Hangar
{
    public int numero;
    public int capacidad;
    public String ubicacion;
    public List<Avion> aviones=new ArrayList<>();

    public Hangar(int numero, int capacidad, String ubicacion) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.ubicacion = ubicacion;
    }

    public void agregarAvion(Avion a){
        if (!aviones.contains(a)){
            aviones.add(a);
            a.agregarHangar(this.numero);

        }
    }
}
