public class Avion {
    public int matricula;
    public String tipo;
    public int numero_modelo;
    public int capacidad;
    public int peso;
    public String fecha_adquisicion;
    public Propietario propietario;
    public int hangar;
    public Avion(int matricula, String tipo, int numero_modelo, int capacidad, int peso, String fecha_adquisicion) {
        this.matricula = matricula;
        this.tipo = tipo;
        this.numero_modelo = numero_modelo;
        this.capacidad = capacidad;
        this.peso = peso;
        this.fecha_adquisicion = fecha_adquisicion;
        this.propietario=null;
        this.hangar=0;
    }
    public void agregarHangar(int hangar){
        this.hangar=hangar;
    }

    public int getMatricula() {
        return matricula;
    }

    public String getTipo() {
        return tipo;
    }
    public void setPropietario(Propietario propietario){
        this.propietario=propietario;
    }

    public int getNumero_modelo() {
        return numero_modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }
    public Propietario getPropietario(){
        return propietario;
    }

    public int getPeso() {
        return peso;
    }
    public int getHangar(){
        return hangar;
    }

    public String getFecha_adquisicion() {
        return fecha_adquisicion;
    }
}
