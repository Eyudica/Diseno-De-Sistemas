public class Main {
    public static void main(String[] args) {
        Avion a1 = new Avion(101, "Comercial", 2020, 180, 50000, "2021-03-15");
        Avion a2 = new Avion(102, "Privado", 2019, 6, 2000, "2020-07-10");
        Avion a3 = new Avion(103, "Carga", 2021, 2, 10000, "2022-01-20");
        Piloto piloto1=new Piloto(12,"juan","mendoza",32,43,3434,"Ninguno","Comercial");
        Piloto piloto2=new Piloto(12,"juan","mendoza",32,43,3434,"Ninguno","Privado");
        Propietario propietario=new Propietario(112,"Juan","mendoza",234234,2342,234);
        Hangar h1 = new Hangar(1, 5, "Aeropuerto Mendoza");
        //hangar
        h1.agregarAvion(a1);
        h1.agregarAvion(a2);
        h1.agregarAvion(a3);
        for (Avion a : h1.aviones){
            System.out.println(a.getMatricula());
        }
        System.out.println(a1.getHangar());

       //piloto-avion
        piloto1.avion = a1;
        piloto1.volarAvion();
        piloto2.avion=a2;
        piloto2.volarAvion();
        // Caso 2: avión no permitido
        piloto1.avion = a2;
        piloto1.volarAvion(); //

        // Caso 3: sin avión
        piloto1.avion = null;
        piloto1.volarAvion();
        a1.setPropietario(propietario);
        System.out.println("El avion a1 es de "+a1.getPropietario().getNombre());

        //registros
        Mecanico mecanico1=new Mecanico(312,"pedro","f",123,342,423,"Comercial");
        mecanico1.generarRegistro("Arreglo de avion","diciembre",312,"tipo");
        mecanico1.arreglarAvion(a1);
        propietario.comprarAvion(a2);
    }}
