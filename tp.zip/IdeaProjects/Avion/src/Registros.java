public class Registros {
    public String fecha;
    public int numero;
    public String tipo;

    public Registros(String fecha, int numero, String tipo) {
        this.fecha = fecha;
        this.numero = numero;
        this.tipo = tipo;
    }
}
