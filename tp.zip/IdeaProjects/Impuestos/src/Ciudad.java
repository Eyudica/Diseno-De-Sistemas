import java.util.List;
public class Ciudad {
    private int gastos;
    private int recaudacion;
    private Boolean deficit;
    private List<Impuesto> impuesto;

    public Ciudad(int gastos, int recaudacion, Boolean deficit, List<Impuesto> impuesto) {
        this.gastos = gastos;
        this.recaudacion = recaudacion;
        this.deficit = deficit;
        this.impuesto=impuesto;
    }

    public int getGastos() {
        return gastos;
    }

    public int getRecaudacion() {
        return recaudacion;
    }

    public Boolean getDeficit() {
        return deficit;
    }

    public void setGastos(int gastos) {
        this.gastos = gastos;
    }

    public void setRecaudacion(int recaudacion) {
        this.recaudacion = recaudacion;
    }

    public void setDeficit(Boolean deficit) {
        this.deficit = deficit;
    }
    public List<Impuesto> getImpuesto(){
        return impuesto;
    }
}
