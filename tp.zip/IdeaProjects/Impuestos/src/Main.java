import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        Impuesto imp1 = new Impuesto(100000,"Autos1","Automotor");
        Impuesto imp2 = new Impuesto(100000,"Autos2","Automotor");
        Impuesto imp3 = new Impuesto(100000,"Autos3","Automotor");
        Impuesto imp4 = new Impuesto(100000,"Autos4","Automotor");
        Impuesto imp5 = new Impuesto(100000,"Autos5","Automotor");
        Ciudad lujan = new Ciudad(11231,234234,true,new ArrayList<>());
        lujan.getImpuesto().add(imp1);
        lujan.getImpuesto().add(imp2);
        lujan.getImpuesto().add(imp3);
        lujan.getImpuesto().add(imp4);
        lujan.getImpuesto().add(imp5);
        for (Impuesto i : lujan.getImpuesto()){
            System.out.println(i.getNombre());
        }

    }
}