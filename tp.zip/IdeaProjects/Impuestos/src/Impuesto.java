public class Impuesto {
    private int monto;
    private String nombre;
    private String tipo;

    public Impuesto(int monto, String nombre, String tipo) {
        this.monto = monto;
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public int getMonto() {
        return monto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }
}
